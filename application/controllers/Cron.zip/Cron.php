<?php defined('BASEPATH') or exit('No direct script access allowed');

class Cron extends CI_Controller
{
	public $data = [];

	public function __construct()
	{
		parent::__construct();
		//$this->load->database();

		$this->load->model('Cron_model', 'cron');
	}

	private function respond($message, $statusCode = 200)
	{
		http_response_code($statusCode);
		echo $message;
	}

	public function whats_alert()
	{
		$clientes = $this->cron->getClientes();

		// Verifica se $clientes é um array válido antes de iterar sobre ele
		if (!is_array($clientes) || empty($clientes)) {
			$this->respond("Nenhum cliente ativo encontrado.");
			return;
		}

		// Loop pelos clientes
		foreach ($clientes as $cliente) {
			$instances = $this->cron->getInstances($cliente->id);

			// Verifica se $instances é um array válido antes de iterar sobre ele
			if (!is_array($instances) || empty($instances)) {
				continue; // Pula para o próximo cliente se não houver instâncias
			}

			// Loop pelas instâncias do cliente
			foreach ($instances as $instance) {
				$gruposMonitorados = $this->cron->getGruposMonitorados($cliente->id, $instance->instance_key);

				// Verifica se $instances é um array válido antes de iterar sobre ele
				if (!is_array($gruposMonitorados) || empty($gruposMonitorados)) {
					continue; // Pula para o próximo cliente se não houver instâncias
				}

				// Loop pelas instâncias do cliente
				foreach ($gruposMonitorados as $grupoMonitorado) {
					$itensMonitorados = $this->cron->getItensMonitorados($cliente->id, $instance->id, $grupoMonitorado->id);

					// Verifica se $instances é um array válido antes de iterar sobre ele
					if (!is_array($itensMonitorados) || empty($itensMonitorados)) {
						continue; // Pula para o próximo cliente se não houver instâncias
					}

					// Recupera as mensagens uma vez para todos os itens monitorados
					$messages = $this->cron->getMessages();

					// Verifica se $messages é um array válido antes de iterar sobre ele
					if (!is_array($messages) || empty($messages)) {
						continue; // Pula para o próximo cliente se não houver mensagens
					}

					// Loop pelos itens monitorados
					foreach ($itensMonitorados as $itemMonitorado) {
						// Imprime o ID do cliente e o ID da instância
						echo "<strong>Cliente ID: " . $cliente->id . ", Instance ID: " . $instance->id . ", GrupoMonitorado ID: " . $grupoMonitorado->id . ", ItemMonitorado ID: " . $itemMonitorado->id . "</strong><br>";

						foreach ($messages as $message) {
							// Verificar se o remetente é um membro do grupo
							if ($itemMonitorado->is_member == 't') {
								$senderId = strstr($message->sender_id, '@', true); // Remove tudo depois do '@'

								// Verificar se o remetente corresponde ao valor monitorado
								if ($itemMonitorado->value == $senderId) {
									$dados = [
										"cliente_id" => $cliente->id,
										"instance_id" => $instance->id,
										"monitored_group_id" => $grupoMonitorado->id,
										"monitored_item_id" => $itemMonitorado->id,
										"message_id" => $message->id
									];

									$alerts = $this->cron->insertWhatsAlert($dados);

									if ($alerts) {
										echo "Cliente ID: " . $cliente->id . ", Instance ID: " . $instance->id . ", GrupoMonitorado ID: " . $grupoMonitorado->id . ", ItemMonitorado ID: " . $itemMonitorado->id .  ", Message ID: " . $message->id . "<br>";
									}
								}
							}
							// Verificar se o remetente não é um membro do grupo
							elseif ($itemMonitorado->is_member == 'f') {
								$texto = $message->content;
								$palavra = $itemMonitorado->value;

								// Remover acentos da palavra a ser buscada
								$palavra_sem_acentos = preg_replace('/[^\p{L}]/u', '', $palavra);

								// Utilizar expressão regular com o modificador 'iu' para busca case insensitive e unicode
								if (preg_match("/\b$palavra_sem_acentos\b/iu", $texto)) {
									$dados = [
										"cliente_id" => $cliente->id,
										"instance_id" => $instance->id,
										"monitored_group_id" => $grupoMonitorado->id,
										"monitored_item_id" => $itemMonitorado->id,
										"message_id" => $message->id
									];

									$alerts = $this->cron->insertWhatsAlert($dados);

									if ($alerts) {
										echo "Cliente ID: " . $cliente->id . ", Instance ID: " . $instance->id . ", GrupoMonitorado ID: " . $grupoMonitorado->id . ", ItemMonitorado ID: " . $itemMonitorado->id .  ", Message ID: " . $message->id . "<br>";
									}
								}
							}
						}

						// Marca as mensagens como verificadas após o processamento
						foreach ($messages as $message) {
							$dados = [
								"cron_checked" => true
							];

							$updateMessage = $this->cron->updateWhatsMessage($dados, $message->id);
						}

						echo "<br>";
						echo "<br>";
					}
				}
			}
		}
	}
}
